/*
 * This file is part of the Micro Vision Device MVD project.
 * Copyright (c) 2016 Micro Vision Device <mvdevice@outlook.com>
 *
 * line_following example.
 *
 */
#include "stm32h7xx_hal.h"
#include "imlib.h"
#include "bsp_mcu.h"
#include "sensor.h"
#include "imlib.h"

void example_line_following(void)
{

}

